# R MarkDown 사용하기
install.packages("rmarkdown")

# R MarkDown 참고
# 공식 사이트
# https://rmarkdown.rstudio.com/lesson-1.html
# 비디오 보기

# https://www.rstudio.com/wp-content/uploads/2015/03/rmarkdown-reference.pdf?_ga=2.1705393.1683083806.1605512097-601360971.1605512097

# File -> New File -> R MarkDown -> Title: example_1 / Author: Seongmin Mun
# Knit -> Knit to HTML

# getwd()
# setwd("/Users/seongminmun/Desktop/아주대/수업/2023/1학기/사학과특강/이상국교수님/Code/1.Tutorial/")
# dir()
# 
# library(rmarkdown)
# render("example_1.html")


#맥업데이트 이후의 문제들(terminal)
# xcode-select --install
